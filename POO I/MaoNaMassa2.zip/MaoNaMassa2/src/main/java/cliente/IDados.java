package cliente;

public interface IDados {

	public String getDados();
	public String getDados(String obs);
}
